Hello, this is the new default writefile path!
So, if you don't use an absolute path, your files written by the writefile function will be saved here.
Thanks for reading me :D
You can delete this folder if you want but it'll get created again when writefile is invoked (with a relative path).