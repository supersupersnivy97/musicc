--put your scripts in this folder if you want to execute them on the injection
--this file will be executed too, inject and check roblox dev console

print("Hey I'm the readme file")