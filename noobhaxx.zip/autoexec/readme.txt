--[[put your scripts in this folder if you want to execute them on the injection
this file will be executed too, try writing a script below]]

--code goes here