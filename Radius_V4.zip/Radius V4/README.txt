Thanks for choosing Radius!
Made by Enoki#0001

TIP: Unless you want an outdated version of Radius and a DLL that doesn't work, use the bootstrapper whenever you
want to use radius. If you want the source as proof that there isn't a virus, DM me on Discord.

Current custom features:
Custom UI
Custom Shortcuts (Type them in the script box and press execute to use them)
- Current Shortcuts: reviz, ftf, energize, swim, potatohub. (Potatohub requires a not shitty computer to use, otherwise your game will crash)

Upcoming custom features:
Tab system (Next Update)
Script Hub (Next Update)
Customizable colors (Next Update)
Themes that make it look like different exploits (WILL BE RELEASED SEPERATELY!)
Custom other themes that make it look refined, but might remove features (WILL ALSO BE RELEASED SEPERATELY)

KNOWN Bugs:
Sometimes, the script box text color will randomly turn red (DOES NOT HAPPEN OFTEN)

If you witness a bug, please report it to Enoki#0001.
